 $(function() {
    var data = [
      { label: 'Deloitte A',     value: 25 },
      { label: 'Deloitte B', value: 40 },
      { label: 'Deloitte C', value: 25 },
      { label: 'Deloitte D',   value: 10 },
    ];

    new Morris.Donut({
      element:    'morrisjs-donut',
      data:       data,
      colors:     ['rgba(0,0,0,0.2)', 'rgba(107,206,200,0.9)', 'rgba(250,133,100,0.9)', 'rgba(30,56,86,0.8)'],
      resize:     true,
      labelColor: '#888',
      formatter:  function (y) { return y + "%" }
    });
	
	var resources = [
      { label: 'A', value:15 },
      { label: 'B', value:30 },
      { label: 'C', value:35 },
      { label: 'D',   value:20 },
    ];
	
	new Morris.Donut({
      element:    'morrisjs-donut2',
      data:       resources,
      colors:     ['rgba(242,134,141,0.7)', 'rgba(83,119,200,0.9)', 'rgba(245,186,100,0.9)', 'rgba(30,56,86,0.8)'],
      resize:     true,
      labelColor: '#888',
      formatter:  function (y) { return y + "%" }
    });


var day_data = [
  {"period": "2012-10-01", "licensed": 3407, "sorned": 660},
  {"period": "2012-09-30", "licensed": 3351, "sorned": 629},
  {"period": "2012-09-29", "licensed": 3269, "sorned": 618},
  {"period": "2012-09-20", "licensed": 3246, "sorned": 661},
  {"period": "2012-09-19", "licensed": 3257, "sorned": 667},
  {"period": "2012-09-18", "licensed": 3248, "sorned": 627},
  {"period": "2012-09-17", "licensed": 3171, "sorned": 660},
  {"period": "2012-09-16", "licensed": 3171, "sorned": 676},
  {"period": "2012-09-15", "licensed": 3201, "sorned": 656},
  {"period": "2012-09-10", "licensed": 3215, "sorned": 622}
];
Morris.Bar({
  element: 'chart',
  data: day_data,
  barColors:     ['rgba(242,134,141,0.7)', 'rgba(83,119,200,0.9)'],
  xkey: 'period',
  ykeys: ['licensed', 'sorned'],
  labels: ['Licensed', 'SORN'],
  xLabelAngle:90
});
	
  });