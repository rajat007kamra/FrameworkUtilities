(function() {

if($("#graph").length != 0){
// Use Morris.Area instead of Morris.Line
Morris.Area({
  element: 'graph',
  behaveLikeLine: true,
  data: [
    {x: '2011 Q1', y: 3, z: 3},
    {x: '2011 Q2', y: 2, z: 1},
    {x: '2011 Q3', y: 2, z: 4},
    {x: '2011 Q4', y: 3, z: 3}
  ],
  xkey: 'x',
  ykeys: ['y', 'z'],
  labels: ['Y', 'Z'],
  lineColors: ['#73a8e4', '#b3d7c9']
});
}
if($("#donut-example").length != 0){
Morris.Donut({
  element: 'donut-example',
  data: [
    {label: "Total Tasks", value: 50},
    {label: "My Tasks", value: 30},
    {label: "Queued Tasks", value: 20}
  ],
  backgroundColor: 'transparent',
  labelColor: '#4d5358',
  colors: [
    '#73a8e4',
    '#91c685',
    '#d08085'
  ]
});
}

	$(".togglemenu").on("click", function(){
	var $side = $("#sidebar");
	if($side.hasClass("close")){
	$($side).removeClass("close");
	}
	else{
		$($side).addClass("close");
	}
});

//steps 
var activelink = $(".steps-container .steps-header h3.active");
var activediv = $(activelink).next("h3").find("a").attr("href");
 
$(".steps-footer #submit").on("click", function(){
	activelink = $(".steps-container .steps-header h3.active");
	activediv = $(activelink).next("h3").find("a").attr("href");
	
	console.log(activediv);
	if(activediv){
	$(".steps-container .steps-header h3").removeClass("active");
	$(".steps-body").addClass("fade").css("display","none");	
	$(activelink).next("h3").addClass("active");
	$(activediv).removeClass("fade").css("display","block");	
	}
	else if(!activediv){
	$(this).attr("disabled","disabled");	
	}
});

$(".steps-container .steps-header h3").on("click", function(e){
	$(".steps-container .steps-header h3").removeClass("active");
	$(this).addClass("active");
	$(".steps-body").addClass("fade").css("display","none");
	var activediv = $(this).find("a").attr("href");
	if(activediv){
	$(activediv).removeClass("fade").css("display","block");
	$(".steps-footer #submit").removeAttr("disabled");
	console.log(activediv);
	}
	e.preventDefault();
});

})(jQuery);